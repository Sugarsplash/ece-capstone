//**************************************************
//     Copyright (c) 2014 Laird Technologies.
//     Copyright (c) 2015 Jennifer AUBINAIS.
//**************************************************
package com.ja.serial;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;

import android.widget.ListView;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.lairdtech.bt.BluetoothAdapterWrapperCallback;
import com.ja.serial.serialdevice.SerialManager;
import com.ja.serial.serialdevice.SerialManagerUiCallback;
import com.lairdtech.bt.BluetoothAdapterWrapper;
import com.lairdtech.bt.ble.BleDeviceBase;
import com.lairdtech.misc.DebugWrapper;

import java.util.Set;


public class MainActivity extends Activity implements SerialManagerUiCallback, BluetoothAdapterWrapperCallback {

    private ToggleButton mBtnSend;

    private int mConnect;

    private SerialManager mSerialManager;

    private static final int ENABLE_BT_REQUEST_ID = 1;
    private final static String TAG = "Base Activity";
    protected Activity mActivity;

    protected BluetoothAdapterWrapper mBluetoothAdapterWrapper;
    protected Dialog mDialogFoundDevices;
    //protected Dialog mDialogNoDevice;

    protected ListFoundDevicesHandler mListFoundDevicesHandler = null;

    private BleDeviceBase mBleDeviceBase;


    protected boolean isInNewScreen = false;
    protected boolean isPrefRunInBackground = true;
    protected boolean isPrefPeriodicalScan = true;
    private boolean isSwitched=true;

    public static final int CONNECT_SCAN = 0;
    public static final int CONNECT_DISCONNECT = 1;
    public static final int CONNECT_CONNECTING = 2;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        mActivity = this;
        setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);

        mSerialManager = new SerialManager(this, this);
        setBleDeviceBase(mSerialManager.getVSPDevice());

        mBluetoothAdapterWrapper = new BluetoothAdapterWrapper(this,this);

        mBtnSend = (ToggleButton) findViewById(R.id.btnSend);

        mListFoundDevicesHandler = new ListFoundDevicesHandler(this);
        initialiseDialogFoundDevices("Select a device");
        //initialiseDialogNoDevice("No Device Found");
        mActivity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        setListeners();


    }


    @Override
    protected void onPause(){
        super.onPause();

        if(isInNewScreen || isPrefRunInBackground){
            // let the app run normally in the background
        } else{
            // stop scanning or disconnect if we are connected
            if(mBluetoothAdapterWrapper.isBleScanning()){
                mBluetoothAdapterWrapper.stopBleScan();

            } else if(getBleDeviceBase().isConnecting()
                    || getBleDeviceBase().isConnected()){
                getBleDeviceBase().disconnect();
            }
        }
    }

    // add the actions to action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actions, menu);
         return true;
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu){
        MenuItem connection=menu.findItem(R.id.action_scan);
        if(mConnect==0) {
            connection.setTitle(R.string.btn_scan);
        }else if(mConnect==1){
            connection.setTitle(R.string.btn_disconnect);
        }else if(mConnect==2){
            connection.setTitle(R.string.btn_connecting);
        }

        uiInvalidateBtnScanState();
        return super.onPrepareOptionsMenu(menu);
    }

    //respond to action buttons
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.action_scan: {
                // set onClickListener for the action scan button
                if (!mBluetoothAdapterWrapper.isEnabled()) {
                    DebugWrapper.errorMsg("Bluetooth must be on to start scanning.", TAG, DebugWrapper.getDebugMessageVisibility());
                    DebugWrapper.toastMsg(mActivity, "Bluetooth must be on to start scanning.");
                    return false;
                } else if (!mBleDeviceBase.isConnected()
                        && !mBleDeviceBase.isConnecting()) {

                    // do a scan operation
                    if (isPrefPeriodicalScan) {
                        mBluetoothAdapterWrapper.startBleScanPeriodically();
                    } else {
                        mBluetoothAdapterWrapper.startBleScan();
                    }

                    mDialogFoundDevices.show();

                    // disconnect
                } else if (mBleDeviceBase.isConnected()) {
                    mBleDeviceBase.disconnect();

                } else if (mBleDeviceBase.isConnecting()) {
                    DebugWrapper.toastMsg(mActivity, "Wait for connection!");
                }
                uiInvalidateBtnScanState();

                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    /*
     * *************************************
     * SerialManagerUiCallback
     * *************************************
     */
    @Override
    public void onUiConnected(BluetoothGatt gatt) {
        uiInvalidateBtnScanState();
    }

    @Override
    public void onUiDisconnect(BluetoothGatt gatt) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                mBtnSend.setEnabled(false);
            }
        });
        uiInvalidateBtnScanState();
    }

    @Override
    public void onUiConnectionFailure(
            final BluetoothGatt gatt){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                mBtnSend.setEnabled(false);
            }
        });
        uiInvalidateBtnScanState();
    }

    @Override
    public void onUiBatteryReadSuccess(String result) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onUiReadRemoteRssiSuccess(int rssi) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onUiBonded() {
        // TODO Auto-generated method stub

    }

    @Override
    public void onUiVspServiceNotFound(BluetoothGatt gatt) {
        runOnUiThread(new Runnable(){
            @Override
            public void run() {

                mBtnSend.setEnabled(false);
            }
        });
    }

    @Override
    public void onUiVspRxTxCharsNotFound(BluetoothGatt gatt) {
        runOnUiThread(new Runnable(){
            @Override
            public void run() {

                mBtnSend.setEnabled(false);
            }
        });
    }

    @Override
    public void onUiVspRxTxCharsFound(BluetoothGatt gatt) {
        runOnUiThread(new Runnable(){
            @Override
            public void run() {

                mBtnSend.setEnabled(true);
            }
        });
    }

    @Override
    public void onUiSendDataSuccess(
            final String dataSend) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //mValueVspOutTv.append(dataSend);
                //mScrollViewVspOut.smoothScrollTo(0, mValueVspOutTv.getBottom());
            }
        });
    }

    @Override
    public void onUiReceiveData(final String dataReceived) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //mValueVspOutTv.append(dataReceived);
                //mScrollViewVspOut.smoothScrollTo(0, mValueVspOutTv.getBottom());
            }
        });
    }

    @Override
    public void onUiUploaded() {

        mBtnSend.setEnabled(true);
    }

    /**
     * Set the bleDevice base to the specific device manager for each application within the toolkit.
     * This ensures it is not null
     * @param bleDeviceBase
     */
    protected void setBleDeviceBase(BleDeviceBase bleDeviceBase){
        mBleDeviceBase = bleDeviceBase;
    }

    protected BleDeviceBase getBleDeviceBase(){
        return mBleDeviceBase;
    }

    /**
     * used for setting handler and adapter for the dialog listView.
     */
    protected void setAdapters() {
        //setting handler and adapter for the dialog list view
        mListFoundDevicesHandler = new ListFoundDevicesHandler(this);
    }

    /**
     * used to set onClickListener for the generic send button.
     */
    protected void setListeners() {
           mBtnSend.setOnClickListener(new OnClickListener() {
               @Override
               public void onClick(View v) {
                   switch (v.getId()) {
                       case R.id.btnSend: {
                           isSwitched = !isSwitched;
                           if (isSwitched) {
                               mSerialManager.startDataTransfer(0 + "\r");
                           } else {
                               mSerialManager.startDataTransfer(1 + "\r");
                           }

                           mBtnSend.setEnabled(false);

                           break;
                       }

                   }
               }

           });

    }

    /**
     * Initialize the dialog for the devices found from a BLE scan.
     * @param title
     */
    protected void initialiseDialogFoundDevices(String title) {
    //protected void initialiseDialogFoundDevices(){
		/*
		 * create/set dialog ListView
		 */
        final ListView mLvFoundDevices = new ListView(mActivity);
        mLvFoundDevices.setAdapter(mListFoundDevicesHandler);
        mLvFoundDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
                final BluetoothDevice device = mListFoundDevicesHandler.getDevice(position);
                if(device == null){

                    return;
                }

                mBluetoothAdapterWrapper.stopBleScan();
                mDialogFoundDevices.dismiss();

                mBleDeviceBase.connect(device, false);
                uiInvalidateBtnScanState();

            }
        });

		/*
		 * create and initialise Dialog
		 */
        mDialogFoundDevices = new Dialog(this);
        mDialogFoundDevices.setContentView(mLvFoundDevices);
        mDialogFoundDevices.setTitle(title);
        mDialogFoundDevices.setCanceledOnTouchOutside(false);
        mDialogFoundDevices.setOnCancelListener(new OnCancelListener() {
            @Override
            public void onCancel(DialogInterface arg0) {
                mBluetoothAdapterWrapper.stopBleScan();
                invalidateOptionsMenu();

            }
        });

        mDialogFoundDevices.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface arg0) {
                mListFoundDevicesHandler.clearList();
            }
        });
    }

    /**
     * Dialog shown when there is no device found
      */
   // protected void initialiseDialogNoDevice(String title) {
     //   mDialogNoDevice = new Dialog(this);
       // mDialogNoDevice.setTitle(title);
        //mDialogNoDevice.setCanceledOnTouchOutside(false);
        //mDialogNoDevice.setOnCancelListener(new OnCancelListener() {
          //  @Override
            //public void onCancel(DialogInterface arg0) {
              //  mBluetoothAdapterWrapper.stopBleScan();
                //invalidateOptionsMenu();

            //}
        //});
    //}



    /**
     * Add the found devices to a listView in the dialog.
     * @param device
     * @param rssi
     * @param scanRecord
     */
    protected void handleFoundDevice(final BluetoothDevice device,
                                     final int rssi,
                                     final byte[] scanRecord){
        //adds found devices to list view
        runOnUiThread(new Runnable(){
            @Override
            public void run() {
                mListFoundDevicesHandler.addDevice(device, rssi, scanRecord);
                mListFoundDevicesHandler.notifyDataSetChanged();
            }
        });
    }

    protected void onResume() {
        super.onResume();
        loadPref();
        isInNewScreen = false;
        //check that BT is enabled as use could have turned it off during the onPause.
        if (!mBluetoothAdapterWrapper.isEnabled()){
            Intent enableBTIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBTIntent, ENABLE_BT_REQUEST_ID);
        }
    }

    public void onBackPressed(){
        if(mBleDeviceBase.isConnected()){
            mBleDeviceBase.disconnect();
            invalidateOptionsMenu();
        }else{
            finish();
        }
    }


    protected void invalidateUI() {

        invalidateOptionsMenu();
    }


    /**
     * invalidate the scan button state
     */
    protected void uiInvalidateBtnScanState(){
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if(!mBleDeviceBase.isConnected()
                        && !mBleDeviceBase.isConnecting()){
                    mConnect=CONNECT_SCAN;
                    setStatus("not connected");

                } else if(mBleDeviceBase.isConnected()){
                    mConnect=CONNECT_DISCONNECT;
                    setStatus("connected");

                } else if(mBleDeviceBase.isConnecting()){
                    mConnect=CONNECT_CONNECTING;
                    setStatus("connecting...");
                }

                invalidateOptionsMenu();
            }
        });
    }

    // set subtitle on the actions bar
    protected void setStatus(CharSequence subTitle){
        ActionBar actionBar=getActionBar();

            actionBar.setSubtitle(subTitle);


        }



    //toggle button
    public void onToggleClicked(View view){
           boolean isSwitched = ((ToggleButton) view).isChecked();
          if(mBleDeviceBase.isConnected()) {
              mBtnSend.setEnabled(true);
              if (isSwitched) {

              } else {

              }
          }

    }


	/*
	 *************************************
	 * Bluetooth adapter callbacks
	 * ***********************************
	 */

    @Override
    public void onBleStopScan() {
        // dismiss' dialog if no devices are found.
        if(mListFoundDevicesHandler.getCount() <= 0){

            //final TextView mNoDevice= (TextView)findViewById(R.id.noDevice);
            //TextView mNoDevice= new TextView(mActivity);
            //mDialogFoundDevices.setContentView(mNoDevice);
            //mNoDevice.setText(R.string.none_found);

            //mDialogNoDevice.show();
            DebugWrapper.toastMsg(mActivity, "No device found");

            mDialogFoundDevices.dismiss();
        }
        uiInvalidateBtnScanState();
    }

    @Override
    public void onBleDeviceFound(BluetoothDevice device, int rssi,
                                 byte[] scanRecord) {
        handleFoundDevice(device, rssi, scanRecord);
    }

    @Override
    public void onDiscoveryStop() {
        //NOT NEEDED
    }

    @Override
    public void onDiscoveryDeviceFound(BluetoothDevice device, int rssi) {
        //NOT NEEDED
    }

    protected void loadPref() {
        //isPrefRunInBackground = mSharedPreferences.getBoolean("pref_run_in_background", true);
        //isPrefPeriodicalScan = mSharedPreferences.getBoolean("pref_periodical_scan", true);
    }

}